

const ChitList = (props) => {
return(
    <div className="chitlist">
        <li>{props.name}</li>
    </div>
)
}

export default ChitList;